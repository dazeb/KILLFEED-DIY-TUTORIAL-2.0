import mod from "./globals.js";

export default mod;
export const FormattingPatterns = mod.FormattingPatterns;
