"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ping.js.map