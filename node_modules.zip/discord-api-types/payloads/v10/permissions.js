"use strict";
/**
 * Types extracted from https://discord.com/developers/docs/topics/permissions
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=permissions.js.map