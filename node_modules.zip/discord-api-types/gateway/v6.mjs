import mod from "./v6.js";

export default mod;
export const GatewayCloseCodes = mod.GatewayCloseCodes;
export const GatewayDispatchEvents = mod.GatewayDispatchEvents;
export const GatewayIntentBits = mod.GatewayIntentBits;
export const GatewayOPCodes = mod.GatewayOPCodes;
export const GatewayVersion = mod.GatewayVersion;
export const VoiceCloseCodes = mod.VoiceCloseCodes;
export const VoiceOPCodes = mod.VoiceOPCodes;
