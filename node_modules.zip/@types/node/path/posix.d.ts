declare module "node:path/posix" {
    import path = require("node:path");
    export = path.posix;
}
declare module "path/posix" {
    import path = require("path");
    export = path.posix;
}
